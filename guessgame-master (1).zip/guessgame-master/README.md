# Guessing Game
Learning Javascript through a Guessing Game.
NOTE: This version does NOT calculate averages!  Add that feature. 
